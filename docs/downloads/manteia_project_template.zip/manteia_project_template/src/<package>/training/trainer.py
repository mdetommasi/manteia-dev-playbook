def run_training():
    pass
