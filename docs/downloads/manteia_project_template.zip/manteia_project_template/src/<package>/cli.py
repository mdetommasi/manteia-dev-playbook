import typer
app = typer.Typer()
@app.command()
def train(config: str = 'configs/train/pretrain.yaml'):
    print('Training with', config)
if __name__=='__main__': app()
