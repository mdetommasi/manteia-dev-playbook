#!/usr/bin/env bash
echo 'Put data in data/'
