#!/usr/bin/env bash
python -m <package>.cli train --config configs/train/pretrain.yaml
