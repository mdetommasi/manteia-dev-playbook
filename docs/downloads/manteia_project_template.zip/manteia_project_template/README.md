# <project_name> — SoH Estimation (Refactor-style)
